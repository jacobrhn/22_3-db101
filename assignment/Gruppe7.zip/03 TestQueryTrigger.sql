-- test error in insert trigger on support

INSERT into SUPPORT (ConfigID, FehlerKategorieID, ErfasserID, PersonalbereichID)
VALUES (
    2, 
    2, 
    1001,
    1
)





